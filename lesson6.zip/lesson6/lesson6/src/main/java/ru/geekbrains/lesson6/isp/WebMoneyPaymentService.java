package ru.geekbrains.lesson6.isp;

public interface WebMoneyPaymentService {

    void payWebMoney(int amount);
}
