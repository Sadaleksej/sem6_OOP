package ru.geekbrains.lesson6.srp2;

public class Order {

    private String clientName;
    private String product;
    private int qnt;
    private int price;


    public Order(){};
    public void setClientName(String name) {
        this.clientName = name;}
    public void setProduct(String prod) {
        this.product = prod;}
    public void setQnt(int quan) {
        this.qnt = quan;}
    public void setPrice(int prc) {
        this.price = prc;}

    public String getProduct() {
        return product;
    }
    public String getClientName() {
        return clientName;
    }
    public int getQnt() {
        return qnt;
    }
    public int getPrice() {
        return price;
    }

}
