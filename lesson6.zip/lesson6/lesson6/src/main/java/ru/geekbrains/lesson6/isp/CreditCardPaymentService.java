package ru.geekbrains.lesson6.isp;

public interface CreditCardPaymentService {

    void payCreditCard(int amount);

}
