package ru.geekbrains.lesson6.ocp1;

public interface ShapeV2 {

    double getArea();

}
