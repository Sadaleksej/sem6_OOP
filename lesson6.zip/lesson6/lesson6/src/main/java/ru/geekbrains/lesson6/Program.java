package ru.geekbrains.lesson6;

public class Program {

    public static void main(String[] args) {

    }

}
