package ru.geekbrains.lesson6.isp;

public abstract class PaymentSrv {
}
