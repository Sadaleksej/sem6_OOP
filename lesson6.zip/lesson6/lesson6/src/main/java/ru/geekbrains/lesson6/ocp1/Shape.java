package ru.geekbrains.lesson6.ocp1;

public interface Shape {
}
