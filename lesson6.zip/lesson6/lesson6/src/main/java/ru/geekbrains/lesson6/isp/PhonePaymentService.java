package ru.geekbrains.lesson6.isp;

public interface PhonePaymentService {

    void payPhoneNumber(int amount);

}
